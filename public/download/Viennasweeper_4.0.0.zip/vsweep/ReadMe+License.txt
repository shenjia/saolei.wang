This copy of vsweep.zip contains:

-VSWEEP (Vienna MineSweeper - Version 4.0.0)

-VSH (ViennaSweeper History - Version 0.1.0)

VSWEEP is a Minesweeper Clone, and VSH is its history
tool.

DO NOT delete the history.sqlite file created by VSWEEP. It
contains not just your history, but also all replays you
did not manually extract. Unlike pre-4.0 versions of vsweep,
replays will not be written to a file anymore by default;
you must manually extract them using VSH.

DO NOT run VSWEEP on an NFS filesystem, or any other
filesystem not supported by sqlite. (NFS is not the same as
NTFS, and NTFS is fine!) That is impossible to officially
support because of technical limitations.
Things might break, and your history might be corrupted; you
have been warned. When in doubt, put VSWEEP on your default
C: drive, or another partition on the same storage device.

Technical note for advanced users:
If you do run VSWEEP on an NFS filesystem, do not use third
party tools to access the sqlite databases while vsweep is
running, even if VSWEEP and VSH work as intended.

Very technical note for super-advanced users:
If, for some reason, you want to interact with VSWEEP's
sqlite databases, and you absolutely must run on NFS - use
the win32 API to acquire the VSWEEP_SQLITE mutex as you do
so. This mutex is acquired by VSWEEP and VSH as an
additional protection, should issues with the underlying FS
implementation prevent sqlite's file locking approach from
working properly.

Should you run into any issues, bug reports are always
appreciated. Please submit them via one of the following
channels:
 - email: thomaskolar90@gmail.com
 - discord: @ralokt


LICENSE

VSWEEP and VSH are freeware. They are provided as
is and come with no warranty of any kind, either expressed
or implied. In no event will the programmers or copyright
holders be liable for any damages resulting from the use of
this software.

You may use, copy or redistribute VSWEEP and VSH.
You MAY NOT make any attempts to decompile or reverse
engineer VSWEEP.
You MAY NOT make any attempts to reconstruct the algorithms
used by VSWEEP.
